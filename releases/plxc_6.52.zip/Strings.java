public class Strings {
    /** A class that contains common methods use to process strings in the compiler.
     *  All Strings have two double-quotes.
     */
}
