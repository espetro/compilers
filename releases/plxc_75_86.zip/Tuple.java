public class Tuple {
    public String id; // "a" is the "ID" String
    public String printable; // "b" is the "writable" String

    public Tuple(String uno, String dos) {
        this.id = uno;
        this.printable = dos;
    }
}
