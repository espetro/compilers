if a > 10:
    print(2)
else:
    print(1)
# Esto da error ('a' no esta inicializada)