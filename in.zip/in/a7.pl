for i in range(1,3):
    print(i)
print(3)