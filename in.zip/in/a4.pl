x = 1
print x