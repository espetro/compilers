i = 1
while i < 5:
    i = i + 1
print i