x = 4
i = 1
factorial = 1
while i < x+1 :
    factorial = factorial * i
    i = i+1

print factorial