'''
Imprime 7
'''
print(3 + 4)
