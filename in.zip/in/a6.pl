i = 3
while i < 5:
    print(i)
    i = i + 1
print(i)