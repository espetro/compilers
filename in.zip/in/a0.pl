print(1)
# print("Esto si")