'''
# print("Esto esta dentro de un comentario")
# print("Y esto")
'''
# print("Esto no esta dentro de un comentario")
print 4