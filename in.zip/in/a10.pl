i = 1
if i == 1:
    print 1
elif i == 2:
    print 2
else:
    print 3